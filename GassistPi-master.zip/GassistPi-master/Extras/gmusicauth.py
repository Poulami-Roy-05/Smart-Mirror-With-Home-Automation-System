from gmusicapi import Mobileclient

api = Mobileclient()

api.perform_oauth()
